// WeatherPanel.qml — the popup body: glass on top, forecast below.
import QtQuick
import QtQuick.Layouts

Rectangle {
    id: panel
    implicitWidth: 472
    implicitHeight: glass.height + hours.height + days.height + 24
    color: Theme.panel
    radius: Theme.radius
    border.width: 1
    border.color: Theme.line
    clip: true

    // live where it matters: the shader parks when the popup is hidden
    property bool active: visible

    Item {
        id: glass
        width: parent.width
        height: 352

        NightScene {
            id: scene
            width: glass.width
            height: glass.height
            skyTop: Theme.skyTop
            skyMid: Theme.skyMid
            skyBottom: Theme.skyBottom
            glow: Theme.glow
            lamp: Theme.lamp
        }

        GlassPane {
            anchors.fill: parent
            scene: scene
            running: panel.active
            fog: WeatherService.fogAmount
            dropRate: WeatherService.dropRate
            bend: 0.055
        }

        // overlay — never inside the shader, so text stays crisp
        Item {
            anchors.fill: parent
            anchors.margins: 22

            ColumnLayout {
                anchors.left: parent.left
                anchors.right: parent.right
                anchors.top: parent.top
                spacing: 2
                RowLayout {
                    Layout.fillWidth: true
                    Text {
                        text: WeatherService.place
                        color: "white"; font.pixelSize: 16; font.weight: Font.DemiBold
                    }
                    Item { Layout.fillWidth: true }
                    Text {
                        text: WeatherService.loaded ? "live" : (WeatherService.error || "…")
                        color: "#ffffffa0"; font.pixelSize: 12
                    }
                }
            }

            Column {
                anchors.left: parent.left
                anchors.bottom: parent.bottom
                spacing: 6
                Text {
                    text: Math.round(WeatherService.temperature) + "°"
                    color: "white"
                    font.family: Theme.numberFont
                    font.pixelSize: 82
                    font.weight: Font.DemiBold
                }
                Text {
                    text: WeatherService.condition
                    color: "#ffffffe6"; font.pixelSize: 17
                }
                Text {
                    text: "Feels like " + Math.round(WeatherService.feelsLike) + "°"
                    color: "#ffffff9e"; font.pixelSize: 14
                }
                Row {
                    spacing: 8
                    Repeater {
                        model: [
                            { v: WeatherService.wind.toFixed(0) + " m/s", k: "WIND" },
                            { v: WeatherService.humidity + "%",           k: "HUMIDITY" },
                            { v: WeatherService.precipitation.toFixed(1) + " mm", k: "RAIN 1H" }
                        ]
                        delegate: Rectangle {
                            required property var modelData
                            radius: Math.min(10, Theme.radius)
                            color: "#ffffff1c"
                            border.color: "#ffffff2b"
                            border.width: 1
                            implicitWidth: chip.width + 22
                            implicitHeight: chip.height + 16
                            Column {
                                id: chip
                                anchors.centerIn: parent
                                spacing: 2
                                Text { text: modelData.v; color: "white"; font.pixelSize: 15; font.weight: Font.DemiBold }
                                Text { text: modelData.k; color: "#ffffffa8"; font.pixelSize: 10; font.letterSpacing: 1.3 }
                            }
                        }
                    }
                }
            }
        }
    }

    Row {
        id: hours
        anchors.top: glass.bottom
        width: parent.width
        padding: 14
        spacing: 2
        Repeater {
            model: WeatherService.hourly
            delegate: Column {
                required property var modelData
                width: (hours.width - 28) / Math.max(1, WeatherService.hourly.length)
                spacing: 7
                Text { text: modelData.time; color: Theme.dim; font.pixelSize: 11
                       anchors.horizontalCenter: parent.horizontalCenter }
                Text { text: modelData.temp + "°"; color: Theme.fgHi; font.pixelSize: 15
                       font.weight: Font.DemiBold; anchors.horizontalCenter: parent.horizontalCenter }
                Rectangle {
                    width: 5
                    height: Math.max(2, modelData.pop * 0.24)
                    radius: 2
                    color: Theme.accent
                    opacity: 0.55
                    anchors.horizontalCenter: parent.horizontalCenter
                }
                Text { text: modelData.pop + "%"; color: Theme.dim; font.pixelSize: 10
                       anchors.horizontalCenter: parent.horizontalCenter }
            }
        }
    }

    Column {
        id: days
        anchors.top: hours.bottom
        width: parent.width
        padding: 10
        Repeater {
            model: WeatherService.daily
            delegate: Item {
                required property var modelData
                width: days.width - 20
                height: 38
                Text {
                    anchors.verticalCenter: parent.verticalCenter
                    x: 8
                    text: modelData.day; color: Theme.fg; font.pixelSize: 14
                }
                Row {
                    anchors.verticalCenter: parent.verticalCenter
                    anchors.right: parent.right
                    anchors.rightMargin: 8
                    spacing: 10
                    Text { text: modelData.lo + "°"; color: Theme.dim; font.pixelSize: 14 }
                    Text { text: modelData.hi + "°"; color: Theme.fgHi; font.pixelSize: 14
                           font.weight: Font.DemiBold }
                }
            }
        }
    }
}
