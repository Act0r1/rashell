pragma Singleton
// Theme.qml — rashell design tokens. One source of truth for every module.
// qmldir must contain:  singleton Theme 1.0 Theme.qml
import QtQuick

QtObject {
    id: theme

    // "oilslick" | "muninn" | "nevermore" | "talon"
    property string name: "oilslick"

    readonly property var sets: ({
        oilslick: {
            fg: "#b7bbc9", fgHi: "#f4f6fc", dim: "#646a7e", accent: "#8a6dff",
            panel: "#0e0e12", line: "#ffffff14", radius: 18, chamfer: 0,
            skyTop: "#171a2e", skyMid: "#2b2350", skyBottom: "#0a0b12",
            glow: "#8a6dff", lamp: "#ffcf8a", serifNumbers: false
        },
        muninn: {
            fg: "#c3bfb3", fgHi: "#eae5d8", dim: "#78746a", accent: "#c9a227",
            panel: "#111214", line: "#2c2c2f", radius: 3, chamfer: 0,
            skyTop: "#1b1a17", skyMid: "#3a3227", skyBottom: "#0d0d0c",
            glow: "#c9a227", lamp: "#e8c877", serifNumbers: true
        },
        nevermore: {
            fg: "#bfb7a7", fgHi: "#e6ded0", dim: "#7a7266", accent: "#a11d33",
            panel: "#0f0d12", line: "#e2d6be24", radius: 10, chamfer: 0,
            skyTop: "#14101a", skyMid: "#2e1620", skyBottom: "#08070a",
            glow: "#a11d33", lamp: "#e0c9a4", serifNumbers: true
        },
        talon: {
            fg: "#9b9da1", fgHi: "#f2f0ea", dim: "#5d6064", accent: "#f2f0ea",
            panel: "#101113", line: "#f2f0ea2e", radius: 0, chamfer: 18,
            skyTop: "#141618", skyMid: "#2a2d31", skyBottom: "#08090b",
            glow: "#f2f0ea", lamp: "#f2f0ea", serifNumbers: false
        }
    })

    readonly property var t: sets[name]

    readonly property color fg:        t.fg
    readonly property color fgHi:      t.fgHi
    readonly property color dim:       t.dim
    readonly property color accent:    t.accent
    readonly property color panel:     t.panel
    readonly property color line:      t.line
    readonly property int   radius:    t.radius
    readonly property int   chamfer:   t.chamfer
    readonly property color skyTop:    t.skyTop
    readonly property color skyMid:    t.skyMid
    readonly property color skyBottom: t.skyBottom
    readonly property color glow:      t.glow
    readonly property color lamp:      t.lamp

    readonly property string sans: "Inter"
    readonly property string serif: "Iowan Old Style"
    readonly property string mono: "JetBrains Mono"
    readonly property string numberFont: t.serifNumbers ? serif : sans
}
