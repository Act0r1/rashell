// WeatherPill.qml — the bar module. Click opens the glass panel.
import QtQuick
import Quickshell

MouseArea {
    id: pill
    // parent bar window, needed to anchor the popup
    required property var barWindow

    implicitWidth: row.width + 26
    implicitHeight: parent ? parent.height : 40
    hoverEnabled: true
    onClicked: popup.visible = !popup.visible

    Rectangle {
        anchors.fill: parent
        anchors.topMargin: 7
        anchors.bottomMargin: 7
        radius: Theme.radius > 0 ? height / 2 : 0
        color: popup.visible ? Qt.alpha(Theme.accent, 0.18)
             : pill.containsMouse ? "#ffffff12" : "transparent"
    }

    Row {
        id: row
        anchors.centerIn: parent
        spacing: 9
        Text {
            anchors.verticalCenter: parent.verticalCenter
            // swap for your icon font / SVG set
            text: ({ rain: "🌧", storm: "⛈", snow: "❄", cloud: "☁", clear: "☾" })[WeatherService.icon] || "•"
            color: Theme.accent
            font.pixelSize: 15
        }
        Text {
            anchors.verticalCenter: parent.verticalCenter
            text: WeatherService.loaded ? Math.round(WeatherService.temperature) + "°" : "--"
            color: Theme.fgHi
            font.family: Theme.numberFont
            font.pixelSize: 15
        }
    }

    PopupWindow {
        id: popup
        anchor.window: pill.barWindow
        anchor.rect.x: pill.mapToItem(null, 0, 0).x + pill.width / 2 - implicitWidth / 2
        anchor.rect.y: pill.barWindow ? pill.barWindow.height : 0
        implicitWidth: body.implicitWidth
        implicitHeight: body.implicitHeight
        color: "transparent"
        visible: false

        WeatherPanel {
            id: body
            active: popup.visible
        }
    }
}
