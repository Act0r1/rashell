// GlassPane.qml — a pane of fogged glass you look through.
//
// Give it a `scene` Item. It renders that scene twice (sharp + blurred),
// runs procedural droplets over it, and lets the pointer wipe the fog.
// Nothing in here is weather-specific: any Item can be the scene.
//
// Requires: Qt 6.5+ (QtQuick.Effects), shaders/rainglass.frag.qsb
import QtQuick
import QtQuick.Effects

Item {
    id: root

    // The thing behind the glass. Parent it anywhere; it is hidden and sampled.
    required property Item scene

    // Look
    property real fog: 1.0          // 0 = clean pane, 1 = fully hazed
    property real dropRate: 0.55    // density of running drops
    property real dropSize: 1.0
    property real bend: 0.055       // refraction strength
    property real blurRadius: 28

    // Behaviour
    property bool running: true     // stop this when the popup is hidden
    property real wipeRadius: 42
    property real refogSeconds: 6

    clip: true

    // 1. the scene, crisp
    ShaderEffectSource {
        id: sharpSrc
        anchors.fill: parent
        sourceItem: root.scene
        hideSource: true
        live: root.running
        visible: false
    }

    // 2. the same scene, blurred — this is what fog looks like
    MultiEffect {
        id: blurPass
        anchors.fill: parent
        source: sharpSrc
        blurEnabled: true
        blur: 1.0
        blurMax: Math.round(root.blurRadius)
        brightness: -0.08
        saturation: 0.12
        visible: false
        layer.enabled: true
    }
    ShaderEffectSource {
        id: blurSrc
        anchors.fill: parent
        sourceItem: blurPass
        hideSource: true
        live: root.running
        visible: false
    }

    // 3. the wipe mask: white where the pointer has cleared the glass.
    //    Deliberately low resolution — it is only ever sampled softly.
    Canvas {
        id: wipeCanvas
        anchors.fill: parent
        renderTarget: Canvas.FramebufferObject
        renderStrategy: Canvas.Cooperative
        visible: false

        property var strokes: []
        property real decay: 0.05

        onPaint: {
            const ctx = getContext("2d");
            // fade previous wiping back toward fogged
            ctx.globalCompositeOperation = "destination-out";
            ctx.fillStyle = Qt.rgba(0, 0, 0, decay);
            ctx.fillRect(0, 0, width, height);

            // add what the pointer touched since the last frame
            ctx.globalCompositeOperation = "source-over";
            ctx.fillStyle = "white";
            for (const s of strokes) {
                const g = ctx.createRadialGradient(s.x, s.y, 0, s.x, s.y, root.wipeRadius);
                g.addColorStop(0.0, "rgba(255,255,255,1)");
                g.addColorStop(0.7, "rgba(255,255,255,0.6)");
                g.addColorStop(1.0, "rgba(255,255,255,0)");
                ctx.fillStyle = g;
                ctx.beginPath();
                ctx.ellipse(s.x - root.wipeRadius, s.y - root.wipeRadius,
                            root.wipeRadius * 2, root.wipeRadius * 2);
                ctx.fill();
            }
            strokes = [];
        }
    }
    ShaderEffectSource {
        id: wipeSrc
        anchors.fill: parent
        sourceItem: wipeCanvas
        hideSource: true
        live: root.running
        visible: false
    }

    // 4. the glass itself
    ShaderEffect {
        id: pane
        anchors.fill: parent

        // NOTE: declaration order must match the std140 block in rainglass.frag
        property real time: 0
        property real fog: root.fog
        property real dropRate: root.dropRate
        property real dropSize: root.dropSize
        property real bend: root.bend
        property real aspect: width / Math.max(1, height)

        property var sharp: sharpSrc
        property var blurred: blurSrc
        property var wipe: wipeSrc

        fragmentShader: Qt.resolvedUrl("../shaders/rainglass.frag.qsb")
    }

    // 5. clock. FrameAnimation gives real frame deltas; it also parks cleanly.
    FrameAnimation {
        running: root.running
        onTriggered: {
            pane.time += frameTime;
            wipeCanvas.decay = frameTime / Math.max(0.5, root.refogSeconds);
            wipeCanvas.requestPaint();
        }
    }

    MouseArea {
        anchors.fill: parent
        hoverEnabled: true
        acceptedButtons: Qt.NoButton
        onPositionChanged: mouse => wipeCanvas.strokes.push({ x: mouse.x, y: mouse.y })
    }
}
