pragma Singleton
// WeatherService.qml — Open-Meteo, no API key, refreshed every 10 minutes.
// qmldir:  singleton WeatherService 1.0 WeatherService.qml
import QtQuick

QtObject {
    id: svc

    property real latitude: 55.7963      // Kazan
    property real longitude: 49.1064
    property string place: "Kazan"

    property bool loaded: false
    property string error: ""

    property real temperature: 0
    property real feelsLike: 0
    property real wind: 0
    property int humidity: 0
    property real precipitation: 0
    property int code: 0                  // WMO weather code
    property bool isDay: true

    property var hourly: []               // [{ time, temp, pop }]
    property var daily: []                // [{ day, code, hi, lo }]

    readonly property string condition: describe(code)
    readonly property string icon: iconFor(code)

    // How hard the glass should rain, straight from the weather code.
    readonly property real dropRate:
        code >= 95 ? 0.95 :
        code >= 80 ? 0.75 :
        code >= 61 ? 0.55 :
        code >= 51 ? 0.25 :
        code >= 71 ? 0.05 : 0.03
    readonly property real fogAmount: code >= 45 ? 1.0 : 0.25

    function describe(c) {
        if (c === 0) return "Clear";
        if (c <= 2) return "Mostly clear";
        if (c === 3) return "Overcast";
        if (c <= 48) return "Fog";
        if (c <= 55) return "Light drizzle";
        if (c <= 65) return "Steady rain";
        if (c <= 77) return "Snow";
        if (c <= 82) return "Rain showers";
        if (c <= 86) return "Snow showers";
        return "Thunderstorm";
    }

    function iconFor(c) {
        if (c === 0 || c <= 2) return "clear";
        if (c === 3 || c <= 48) return "cloud";
        if (c <= 65 || (c >= 80 && c <= 82)) return "rain";
        if (c <= 77 || c <= 86) return "snow";
        return "storm";
    }

    function refresh() {
        const url = "https://api.open-meteo.com/v1/forecast"
            + "?latitude=" + latitude + "&longitude=" + longitude
            + "&current=temperature_2m,apparent_temperature,relative_humidity_2m,"
            + "precipitation,weather_code,wind_speed_10m,is_day"
            + "&hourly=temperature_2m,precipitation_probability,weather_code"
            + "&daily=weather_code,temperature_2m_max,temperature_2m_min"
            + "&timezone=auto&forecast_days=6";

        const req = new XMLHttpRequest();
        req.onreadystatechange = function () {
            if (req.readyState !== XMLHttpRequest.DONE) return;
            if (req.status !== 200) { svc.error = "HTTP " + req.status; return; }
            try {
                const d = JSON.parse(req.responseText);
                const c = d.current;
                svc.temperature = c.temperature_2m;
                svc.feelsLike = c.apparent_temperature;
                svc.humidity = c.relative_humidity_2m;
                svc.precipitation = c.precipitation;
                svc.wind = c.wind_speed_10m;
                svc.code = c.weather_code;
                svc.isDay = c.is_day === 1;

                const now = new Date();
                const rows = [];
                for (let i = 0; i < d.hourly.time.length && rows.length < 7; i++) {
                    const t = new Date(d.hourly.time[i]);
                    if (t < now) continue;
                    rows.push({
                        time: Qt.formatTime(t, "HH:mm"),
                        temp: Math.round(d.hourly.temperature_2m[i]),
                        pop: d.hourly.precipitation_probability[i],
                        code: d.hourly.weather_code[i]
                    });
                }
                svc.hourly = rows;

                const days = [];
                for (let i = 1; i < d.daily.time.length; i++) {
                    days.push({
                        day: Qt.formatDate(new Date(d.daily.time[i]), "ddd"),
                        code: d.daily.weather_code[i],
                        hi: Math.round(d.daily.temperature_2m_max[i]),
                        lo: Math.round(d.daily.temperature_2m_min[i])
                    });
                }
                svc.daily = days;

                svc.error = "";
                svc.loaded = true;
            } catch (e) {
                svc.error = "Bad response";
            }
        };
        req.open("GET", url);
        req.send();
    }

    property Timer poll: Timer {
        interval: 10 * 60 * 1000
        running: true
        repeat: true
        triggeredOnStart: true
        onTriggered: svc.refresh()
    }
}
