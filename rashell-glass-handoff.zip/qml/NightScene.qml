// NightScene.qml — what sits behind the glass.
//
// Cheap, procedural, and deterministic: same skyline every launch.
// Swap this for a crop of the user's wallpaper if you prefer — GlassPane
// does not care what the scene is, only that it is an Item.
import QtQuick

Item {
    id: scene

    property color skyTop: "#171a2e"
    property color skyMid: "#2b2350"
    property color skyBottom: "#0a0b12"
    property color glow: "#8a6dff"
    property color lamp: "#ffcf8a"
    property real glowStrength: 0.34
    property int seed: 8

    Rectangle {
        anchors.fill: parent
        gradient: Gradient {
            GradientStop { position: 0.0;  color: scene.skyTop }
            GradientStop { position: 0.52; color: scene.skyMid }
            GradientStop { position: 1.0;  color: scene.skyBottom }
        }
    }

    // horizon glow
    Rectangle {
        anchors.fill: parent
        opacity: scene.glowStrength
        gradient: Gradient {
            orientation: Gradient.Vertical
            GradientStop { position: 0.35; color: "transparent" }
            GradientStop { position: 0.72; color: Qt.alpha(scene.glow, 0.45) }
            GradientStop { position: 1.0;  color: "transparent" }
        }
    }

    // two ranges of buildings, back one flatter and darker
    Repeater {
        model: 2
        delegate: Item {
            required property int index
            anchors.fill: parent
            Canvas {
                id: range
                anchors.fill: parent
                renderStrategy: Canvas.Cooperative
                onPaint: {
                    const ctx = getContext("2d");
                    ctx.reset();
                    // deterministic PRNG so the skyline never reshuffles
                    let s = scene.seed * 7919 + parent.index * 104729;
                    const rand = () => { s = (s * 1103515245 + 12345) & 0x7fffffff; return s / 0x7fffffff; };

                    const back = parent.index === 0;
                    const base = height * (back ? 0.80 : 0.93);
                    ctx.fillStyle = back ? "rgba(0,0,0,0.42)" : "rgba(0,0,0,0.74)";

                    let x = -20;
                    while (x < width + 20) {
                        const bw = 26 + rand() * (back ? 44 : 56);
                        const bh = (back ? 40 : 60) + rand() * (back ? 90 : 130);
                        ctx.fillRect(x, base - bh, bw, bh + 40);

                        if (!back) {
                            for (let wy = base - bh + 8; wy < base - 6; wy += 11) {
                                for (let wx = x + 5; wx < x + bw - 6; wx += 9) {
                                    if (rand() > 0.78) {
                                        ctx.fillStyle = rand() > 0.25 ? scene.lamp : "#9fd6ff";
                                        ctx.globalAlpha = 0.35 + rand() * 0.6;
                                        ctx.fillRect(wx, wy, 3, 4);
                                        ctx.globalAlpha = 1;
                                        ctx.fillStyle = "rgba(0,0,0,0.74)";
                                    }
                                }
                            }
                        }
                        x += bw + 3 + rand() * 9;
                    }
                }
                Component.onCompleted: requestPaint()
            }
        }
    }
}
