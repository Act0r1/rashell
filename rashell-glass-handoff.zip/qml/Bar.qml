// Bar.qml — minimal wiring so the module can be run on its own.
import QtQuick
import Quickshell

Scope {
    Variants {
        model: Quickshell.screens
        PanelWindow {
            id: bar
            required property var modelData
            screen: modelData
            anchors { top: true; left: true; right: true }
            implicitHeight: 58
            color: "transparent"

            Rectangle {
                anchors.fill: parent
                color: Qt.alpha(Theme.panel, 0.86)
            }

            Row {
                anchors.right: parent.right
                anchors.rightMargin: 10
                height: parent.height
                spacing: 4
                WeatherPill { barWindow: bar }
            }
        }
    }
}
