# Brief: rain-on-glass material for **rashell**

*(Paste this whole file to the implementing agent. Everything it references is in this folder.)*

---

## Who you are and what you're doing

You're implementing a visual material for **rashell**, a custom Quickshell desktop shell (Wayland / Hyprland). "rashell" = raven + shell; the shell's visual language is dark, restrained, and colour is used to mean something rather than to decorate.

The material is called **glass**: the user looks *through* a fogged pane at a scene behind it. Droplets run down the pane, bend the scene behind them like real lenses, and cut clear trails through the fog as they go. Moving the pointer across the pane wipes the fog; it creeps back over a few seconds.

There is a working browser prototype in `reference/rain-glass-reference.html` — **open it first**. That is the target look. It is canvas-based and is only a proof of the look; your job is the real thing in QML.

You have two deliverables. Do them in order and don't start the second until the first actually runs.

---

## Deliverable 1 — Ship the weather module

Port and tune the code in `qml/` until the weather panel matches the reference.

Files provided (all are starting points, not gospel — fix what's wrong):

| File | What it does |
|---|---|
| `shaders/rainglass.frag` | The material. Procedural droplets, refraction, fog blend. |
| `qml/GlassPane.qml` | Wraps the shader: samples a scene sharp + blurred, owns the wipe mask and the clock. **Scene-agnostic by design.** |
| `qml/NightScene.qml` | A cheap deterministic city skyline to sit behind the glass. |
| `qml/Theme.qml` | Design tokens for the four rashell themes. Singleton. |
| `qml/WeatherService.qml` | Open-Meteo fetch, WMO code mapping, 10-minute poll. Singleton. |
| `qml/WeatherPanel.qml` | Popup body: glass on top, hourly strip and 5-day list below. |
| `qml/WeatherPill.qml` | Bar module + `PopupWindow`. |
| `qml/Bar.qml` | Minimal harness so you can run the module standalone. |

Build the shader before running anything:

```sh
qsb --qt6 -o shaders/rainglass.frag.qsb shaders/rainglass.frag
quickshell -p qml/Bar.qml
```

### How the effect actually works

Understand this before you tune it, or you'll chase the wrong knobs.

1. The scene is rendered once into a `ShaderEffectSource` — call it **sharp**.
2. A `MultiEffect` blur of that same source becomes **blurred**. Fog is not a white overlay; fog *is* the blurred scene.
3. A low-resolution `Canvas` holds the **wipe mask**: white where the pointer has cleared the pane, decaying back to transparent every frame.
4. In the fragment shader, droplets are procedural — a hash per grid cell gives one running head per cell plus beads in its wake, and a second denser grid gives static condensation. Each droplet produces two things: a **refraction offset** and a **coverage** value.
5. Final colour is `mix(blurred, sharp, max(coverage, wipe))`, both sampled with the offset applied. That single line is the whole illusion: **a droplet is clear because it shows the sharp texture, not because it is drawn.**

If drops look like stickers, coverage is feeding the blend but the offset isn't reaching the sample — check `bend`.

### Tuning targets

| Uniform | Start | What it changes |
|---|---|---|
| `bend` | 0.055 | Refraction. Above ~0.09 the scene smears; below ~0.02 drops go flat. |
| `dropRate` | from weather code | Share of grid cells carrying a runner. |
| `dropSize` | 1.0 | Radius multiplier. Scale it with panel size or drops shrink on large panels. |
| `fog` | from weather code | Haze where nothing has cleared. |
| `blurRadius` | 28 | Fog softness. Cheap to raise, but watch `blurMax`. |

Also tune, in `GlassPane.qml`: `wipeRadius` (finger size) and `refogSeconds` (how fast fog returns — 6s reads well, under 2s feels twitchy).

### Acceptance criteria

- Runs at 60fps on integrated graphics with the panel open. Measure with `QSG_RENDER_TIMING=1`.
- **Zero GPU work when the popup is closed.** `GlassPane.running` gates the `FrameAnimation` and every `ShaderEffectSource.live`. Verify with a GPU monitor, not by eye.
- Text over the glass is crisp — the overlay is a sibling of the shader, never inside it.
- All four themes in `Theme.qml` restyle the panel *and* the scene palette. Switching themes at runtime doesn't require a restart.
- Weather comes from `WeatherService`, no hardcoded values left in the panel.
- Network failure degrades gracefully: last known values stay on screen, the panel shows a quiet error state, and the pane keeps running.

---

## Deliverable 2 — One more example

Once weather works, **apply the same material to one more module** and show it side by side. The point is to prove the material is reusable, so:

- `GlassPane.qml` must be used **unchanged**. If you need to edit it to make the second module work, that's a signal it wasn't general enough — fix the generality, don't fork it.
- Only two things change: the scene behind the glass, and the content in front.

Pick one and say why you picked it:

- **Now playing** — album art is the scene. Condensation on a car window at night; the drops sit still, the art blooms behind. `dropRate` near zero, `fog` high, `bend` low.
- **Session / power** — the wallpaper is the scene, heavily fogged. Wiping it clear to reach shutdown makes destructive actions feel deliberate.
- **Notification centre** — each notification is a card; the glass covers the empty state, so an empty inbox is a rainy window rather than a "no notifications" label.

Constraints for whichever you pick:
- Same performance budget as above.
- Same tokens from `Theme.qml`. No new colours.
- Copy stays plain: label things by what they do. No weather-poetry in the UI. The raven is in the name and the palette, not in the button text.

Deliver: the QML, a screenshot of each theme, and two or three sentences on what the material added to that module. If it added nothing, say so — that's a useful finding, not a failure.

---

## Things I am not certain about — verify, don't trust

I wrote the starting code without a machine to run it on. Expect these to need fixing:

1. **Quickshell API drift.** `PopupWindow` anchoring has changed between releases (setting `width`/`height` is deprecated in favour of `implicitWidth`/`implicitHeight`, and `anchor.rect` semantics have moved). Check the docs for *your* installed version at `quickshell.org/docs` before debugging my anchoring math.
2. **Qt 6 shaders are pre-compiled.** `fragmentShader` takes a `.qsb`, not GLSL source. The uniform block members must match the `ShaderEffect`'s property *names and declaration order* exactly; a mismatch fails silently or renders black. This is the single most likely thing to be broken.
3. **`MultiEffect` needs QtQuick.Effects (Qt 6.5+).** On older Qt, substitute a two-pass Gaussian of your own.
4. **`Canvas` for the wipe mask may be too slow** at full panel resolution. If it costs you frames, render it at quarter size — the mask is sampled softly, so nobody will see the difference. If `Canvas` is a problem at any size, replace it with a small ping-pong `ShaderEffect` that decays and adds a brush dab per frame.
5. **`hideSource: true`** on the scene sources is what keeps the raw scene from drawing on top of the glass. If you see an unfogged scene, that's why.
6. The droplet field in the shader is my own; it's tuned by eye against the HTML prototype, not derived. Reshape `runners()` freely if you can make it read better — the bead/trail term is the weakest part.

---

## House rules

- One accent colour per theme, and it marks state, not decoration.
- Motion serves the subject. The drops move because rain moves; nothing else on the panel animates for its own sake.
- Respect the compositor: no work while hidden, no timers running against an invisible window.
- Keyboard reachable and readable at a glance — if the temperature isn't legible in a quarter-second, the glass is too thick.
- Commit the `.qsb` build step to whatever build script exists; don't leave a compiled binary as the only copy of the shader.
