#version 440
// rashell — rain-on-glass pane
// Two sampled copies of the same scene (sharp + blurred) plus a wipe mask.
// Droplets are procedural: they bend the SHARP sample and reveal it through the fog.
// Build:  qsb --qt6 -o rainglass.frag.qsb rainglass.frag

layout(location = 0) in vec2 qt_TexCoord0;
layout(location = 0) out vec4 fragColor;

// Order and types here must match the ShaderEffect's property declaration order.
layout(std140, binding = 0) uniform buf {
    mat4  qt_Matrix;
    float qt_Opacity;
    float time;      // seconds, monotonic
    float fog;       // 0..1 how much haze sits on the pane
    float dropRate;  // 0..1 share of grid cells carrying a runner
    float dropSize;  // multiplier on droplet radius
    float bend;      // refraction strength, in UV units
    float aspect;    // pane width / height
};

layout(binding = 1) uniform sampler2D sharp;    // the scene, crisp
layout(binding = 2) uniform sampler2D blurred;  // the same scene, blurred
layout(binding = 3) uniform sampler2D wipe;     // alpha = wiped clear

vec2 hash22(vec2 p) {
    p = vec2(dot(p, vec2(127.1, 311.7)), dot(p, vec2(269.5, 183.3)));
    return fract(sin(p) * 43758.5453123);
}

// One running drop per grid cell: a head travelling down, beads left in its wake.
// Returns vec3(refraction offset .xy, coverage .z)
vec3 runners(vec2 uv, float t, vec2 cells, float rad, float speed) {
    vec2 st = uv * cells;
    vec2 id = floor(st);
    vec2 gv = fract(st) - 0.5;
    vec2 h  = hash22(id);

    if (h.x > dropRate) return vec3(0.0);          // thin the field out

    float sp    = speed * mix(0.7, 1.5, h.y);
    float head  = fract(h.x * 7.31 + t * sp) - 0.5;
    float wob   = sin(head * 8.0 + h.y * 6.2831) * 0.05;
    float ratio = (cells.y / cells.x) * aspect;    // keep drops round on screen

    vec2  dp = vec2(gv.x - wob, (gv.y - head) * ratio);
    float r  = rad * mix(0.6, 1.15, h.y) * dropSize;
    float m  = smoothstep(r, r * 0.25, length(dp));

    // beads clinging along the path above the head
    float above = gv.y - head;
    vec2  bp    = vec2(gv.x - wob, (fract(above * 9.0) - 0.5) / 9.0 * ratio);
    float bead  = smoothstep(r * 0.5, r * 0.12, length(bp))
                * smoothstep(0.0, 0.06, above)
                * smoothstep(0.55, 0.15, above);

    m = clamp(m + bead * 0.9, 0.0, 1.0);
    return vec3(dp * m, m);
}

// Static condensation: small stuck droplets, no motion.
vec3 condensation(vec2 uv, vec2 cells, float rad) {
    vec2 st = uv * cells;
    vec2 id = floor(st);
    vec2 gv = fract(st) - 0.5;
    vec2 h  = hash22(id + 47.13);
    vec2 c  = (h - 0.5) * 0.6;
    float r = rad * (0.35 + h.x * 0.65) * dropSize;
    vec2 dp = gv - c;
    dp.y   *= (cells.y / cells.x) * aspect;
    float m = smoothstep(r, r * 0.25, length(dp));
    return vec3(dp * m, m);
}

void main() {
    vec2 uv = qt_TexCoord0;

    vec3 a = runners(uv,                    time,        vec2(6.0, 1.0), 0.16, 0.10);
    vec3 b = runners(uv + vec2(0.37, 0.11), time * 1.35, vec2(9.0, 1.0), 0.11, 0.14);
    vec3 c = condensation(uv, vec2(34.0, 22.0), 0.30);

    float cover = clamp(a.z + b.z + c.z * 0.75, 0.0, 1.0);
    vec2  off   = (a.xy + b.xy + c.xy * 0.4) * bend;

    float wiped = texture(wipe, uv).a;
    float clr   = clamp(max(cover, wiped), 0.0, 1.0);

    vec4 s = texture(sharp,   uv + off);
    vec4 f = texture(blurred, uv + off * 0.3);
    vec4 col = mix(f, s, clr);

    // haze sits where nothing has cleared the pane
    col.rgb += vec3(0.05, 0.06, 0.08) * fog * (1.0 - clr);

    // specular pop along the top edge of each drop
    float spec = pow(clamp(-off.y * 6.0 / max(bend, 0.0001), 0.0, 1.0), 4.0) * cover;
    col.rgb += spec * 0.25;

    // rim darkening so drops read as volumes, not decals
    col.rgb *= 1.0 - cover * 0.06;

    fragColor = col * qt_Opacity;
}
